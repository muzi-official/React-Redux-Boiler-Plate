 const ActionTypes = {
    SignupUser: "SignupUser",
    SigninUser: "SigninUser",
    SignOut: "SignOut"
}

export default ActionTypes;
